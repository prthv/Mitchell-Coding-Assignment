// Import required java libraries
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;


public class Start extends HttpServlet {


	public void init() {
	}
	public static String claimId="";
	public static String startDate="";
	public static String endDate="";
    public static void uploadXMLClaimFileToLocationAndSetUpRequestVariables(String filePath,HttpServletRequest request,HttpServletResponse response) throws IOException{
		int maxFileSize = 50 * 1024;
		int maxMemSize = 4 * 1024;
		File file;
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		response.setContentType("text/html");
		java.io.PrintWriter out = response.getWriter();
		if (!isMultipart) {
			out.println("<html>");
			out.println("<head>");
			out.println("<title>File upload</title>");
			out.println("</head>");
			out.println("<body>");
			out.println("<p>No file uploaded</p>");
			out.println("</body>");
			out.println("</html>");
			return;
		}
		DiskFileItemFactory factory = new DiskFileItemFactory();
		// maximum size that will be stored in memory
		factory.setSizeThreshold(maxMemSize);
		// Location to save data that is larger than maxMemSize.
		factory.setRepository(new File("c:\\temp"));

		// Create a new file upload handler
		ServletFileUpload upload = new ServletFileUpload(factory);
		// maximum file size to be uploaded.
		upload.setSizeMax(maxFileSize);

		try {
			// Parse the request to get file items.
			List fileItems = upload.parseRequest(request);

			// Process the uploaded file items
			Iterator i = fileItems.iterator();

			while (i.hasNext()) {
				FileItem fi = (FileItem) i.next();
				if (!fi.isFormField()) {
					
					// Get the uploaded file parameters
					String fileName = fi.getName();
					// Write the file
					if (fileName.lastIndexOf("\\") >= 0) {
						file = new File(
								filePath
										+ fileName.substring(fileName
												.lastIndexOf("\\")));
					} else {
						file = new File(
								filePath
										+ fileName.substring(fileName
												.lastIndexOf("\\") + 1));
					}
					fi.write(file);
				} else {
					String fieldName = fi.getFieldName();
					if(fieldName.equals("claimId")){
						claimId = fi.getString();
					}
					if(fieldName.equals("start")){
						startDate = fi.getString();
					}
					if(fieldName.equals("end")){
						endDate = fi.getString();
					}
				}
			}

		} catch (Exception ex) {
			System.out.println(ex);
		}
    }
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, java.io.IOException {
		
		String filepath = getServletContext().getInitParameter("file-upload");
		uploadXMLClaimFileToLocationAndSetUpRequestVariables(filepath,request,response);// The 'file-upload' variable is declared in web-xml
		
		if(!claimId.equals("")){
			getClaim(claimId,response);
		} else if(!startDate.equals("") && !endDate.equals("")){		// have NOT implemented checks to validate the date formats	
			getClaimWithinDateRange(startDate, endDate,response);
		} else {			
			insertClaimOperation(response);
	    }

	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, java.io.IOException {

		doPost(request, response);
	}
	
	public static void getClaim(String ClaimId, HttpServletResponse response){
		try{
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder builder = factory.newDocumentBuilder();
			Document newDoc = builder.newDocument();
			// designate the webservice method to call in the soap message
			org.w3c.dom.Element newRoot = newDoc.createElement("readClaim");
			newDoc.appendChild(newRoot);
			org.w3c.dom.Element id = newDoc.createElement("claimId");
			id.setTextContent(ClaimId);
			newRoot.appendChild(id);
			org.apache.soap.Envelope envelope = new org.apache.soap.Envelope();
			// create a vector for collecting the body elements
			Vector<Element> bodyElements = new Vector<Element> ();
			// obtain the top-level DOM element and place it into the vector
			bodyElements.add(newDoc.getDocumentElement());
			// Create the SOAP body element
			org.apache.soap.Body body = new org.apache.soap.Body();
			
			body.setBodyEntries(bodyElements);
			// Add the SOAP body element to the envelope
			envelope.setBody(body);
			// Build the Message.
			
			org.apache.soap.messaging.Message msg = new org.apache.soap.messaging.Message();
			msg.send(new java.net.URL("http://localhost:8080/hiThere/services/hiThere"), "http://t350.open.ac.us", envelope);
			
			
			System.out
					.println("Sent SOAP Message with Apache HTTP SOAP Client.");
			// receive response from the transport and dump it to
			// the screen
			System.out.println("Waiting for response....");
			org.apache.soap.transport.SOAPTransport st = msg.getSOAPTransport();
			BufferedReader br = st.receive();
			String line = br.readLine();
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			if (line == null) {
				System.out.println("HTTP POST was NOT successful. \n");
			} else {
				while (line != null) {
					//Outputting the claim in form of an xml 
					out.println(line);
					line = br.readLine();
				}
			}
		
			
		}
		catch (Exception e) {
			System.out.println(e.getCause());
		}
	}
	
	
	public static void getClaimWithinDateRange(String startDate, String endDate, HttpServletResponse response){
		try{
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder builder = factory.newDocumentBuilder();
			Document newDoc = builder.newDocument();
			// designate the webservice method to call in the soap message
			org.w3c.dom.Element newRoot = newDoc.createElement("getListOfClaims");
			newDoc.appendChild(newRoot);
			// append the start date to the soap message
			org.w3c.dom.Element startDateElement = newDoc.createElement("startDate");
			startDateElement.setTextContent(startDate);
			newRoot.appendChild(startDateElement);
			// append the end date to the soap message
			org.w3c.dom.Element endDateElement = newDoc.createElement("endDate");
			endDateElement.setTextContent(endDate);
			newRoot.appendChild(endDateElement);
			
			org.apache.soap.Envelope envelope = new org.apache.soap.Envelope();
			// create a vector for collecting the body elements
			Vector<Element> bodyElements = new Vector<Element> ();
			// obtain the top-level DOM element and place it into the vector
			bodyElements.add(newDoc.getDocumentElement());
			// Create the SOAP body element
			org.apache.soap.Body body = new org.apache.soap.Body();
			
			body.setBodyEntries(bodyElements);
			// Add the SOAP body element to the envelope
			envelope.setBody(body);
			// Build the Message.
			
			org.apache.soap.messaging.Message msg = new org.apache.soap.messaging.Message();
			msg.send(new java.net.URL("http://localhost:8080/hiThere/services/hiThere"), "http://t350.open.ac.us", envelope);
			
			
			System.out
					.println("Sent SOAP Message with Apache HTTP SOAP Client.");
			// receive response from the transport and dump it to
			// the screen
			System.out.println("Waiting for response....");
			org.apache.soap.transport.SOAPTransport st = msg.getSOAPTransport();
			BufferedReader br = st.receive();
			String line = br.readLine();
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			if (line == null) {
				System.out.println("HTTP POST was NOT successful. \n");
			} else {
				while (line != null) {
					out.println(line);
					line = br.readLine();
				}
			}
		
			
		}
		catch (Exception e) {
			System.out.println(e.getCause());
		}
	}
	
	public static void insertClaimOperation(HttpServletResponse response) throws IOException{
		Source xml = new StreamSource(new File("create-claim.xml"));
		SchemaFactory schemaFactory = SchemaFactory
				.newInstance("http://www.w3.org/2001/XMLSchema");
		try {
			Schema schema = schemaFactory.newSchema(new File(
					"MitchellClaim.xsd"));
			Validator validator = schema.newValidator();
			validator.validate(xml);
			System.out.println(xml.getSystemId() + " is valid");
		} catch (SAXException e) {
			System.out.println(xml.getSystemId() + " is NOT valid");
			System.out.println("Reason: " + e.getLocalizedMessage());
			response.setContentType("text/HTML");
			PrintWriter out = response.getWriter();
			out.println("<html>");
			out.println("<head>");
			out.println("<title>File upload</title>");
			out.println("</head>");
			out.println("<body>");
			out.println("<p>The provided XML doesnt conform to the schema.</p>");
			out.println("</body>");
			out.println("</html>");
			return;
		}
		
		
		try {
			// get soap body to include in the SOAP envelope
			FileReader fr = new FileReader("create-claim.xml");

			javax.xml.parsers.DocumentBuilder xdb = org.apache.soap.util.xml.XMLParserUtils
					.getXMLDocBuilder();
			org.w3c.dom.Document doc = xdb
					.parse(new org.xml.sax.InputSource(fr));
			if (doc == null) {
				throw new org.apache.soap.SOAPException(
						org.apache.soap.Constants.FAULT_CODE_CLIENT,
						"parsing error");
			}
			
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder builder = factory.newDocumentBuilder();
			Node oldRoot = doc.getDocumentElement();
			Document newDoc = builder.newDocument();
			org.w3c.dom.Element newRoot = newDoc.createElement("helloName");
			newDoc.appendChild(newRoot);
		    newRoot.appendChild(newDoc.importNode(oldRoot, true));
			
			// Create the SOAP envelope
			org.apache.soap.Envelope envelope = new org.apache.soap.Envelope();
			// create a vector for collecting the body elements
			Vector<Element> bodyElements = new Vector<Element> ();
			// obtain the top-level DOM element and place it into the vector
			bodyElements.add(newDoc.getDocumentElement());
			// Create the SOAP body element
			org.apache.soap.Body body = new org.apache.soap.Body();
			
			body.setBodyEntries(bodyElements);
			// Add the SOAP body element to the envelope
			envelope.setBody(body);
			// Build the Message.
			
			
			//send the message
			org.apache.soap.messaging.Message msg = new org.apache.soap.messaging.Message();
			msg.send(new java.net.URL("http://localhost:8080/hiThere/services/hiThere"), "http://t350.open.ac.us", envelope);
			
			
			System.out
					.println("Sent SOAP Message with Apache HTTP SOAP Client.");
			// receive response from the transport and dump it to
			// the screen
			System.out.println("Waiting for response....");
			org.apache.soap.transport.SOAPTransport st = msg.getSOAPTransport();			
			
			BufferedReader br = st.receive();
			String line = br.readLine();	
			response.setContentType("text/xml");
			PrintWriter out = response.getWriter();
			if (line == null) {
				out.println("HTTP POST was NOT successful. \n");
			} else {
				while (line != null) {
					out.println(line);
					line = br.readLine();
				}
			}
		}

		catch (Exception e) {
			System.out.println(e.getCause());
		}
	}

}