package us.ac.open.t350;

public class VehicleInfoType {
	public int ModelYear;
	public String MakeDescription;
	public String ModelDescription;
	public String EngineDescription;
	public String ExteriorColor;
	public String Vin;
	public String LicPlate;
	public String LicPlateState;
	public String LicPlateExpDate;
	public String DamageDescription;
	public int Mileage;
	
}
