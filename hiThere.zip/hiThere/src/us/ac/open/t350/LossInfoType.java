package us.ac.open.t350;


public class LossInfoType {
	public String CauseOfLoss;
	public String LossDescription;
	public String ReportedDate;
}
