package us.ac.open.t350;

public class VehicleListType {
	
public VehicleInfoType VehicleDetails;
}
