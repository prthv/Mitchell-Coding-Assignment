package us.ac.open.t350;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class hiThere {

	public static Connection conn;

	public static void setupConnection()  {
		try {
			String url = "jdbc:sqlserver://PRITHVI\\SQLEXPRESS;databaseName=Mitchell;integratedSecurity=true";
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			conn = DriverManager.getConnection(url);
			conn.setAutoCommit(false); // to ensure atomicity of transactions
		} catch (Exception e) {
			System.out.println("Error while creating connection:"
					+ e.getCause());
		}
	}

	public String helloName(MitchellClaim MitchellClaim) {
		setupConnection();
		try {
			
			String claimInsert = "INSERT INTO Claim "
					+ "VALUES (?,?,?,?,?,?)";
			PreparedStatement insertIntoClaim = conn
					.prepareStatement(claimInsert);
			insertIntoClaim.setString(1, MitchellClaim.ClaimNumber);
			insertIntoClaim.setString(2, MitchellClaim.ClaimantFirstName);
			insertIntoClaim.setString(3, MitchellClaim.ClaimantLastName);
			insertIntoClaim.setString(4, MitchellClaim.Status);
			if (MitchellClaim.LossDate != null && MitchellClaim.LossDate != "") {
				SimpleDateFormat format = new SimpleDateFormat(
						"yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
				Date parsed = format.parse(MitchellClaim.LossDate);
				java.sql.Date sql = new java.sql.Date(parsed.getTime());
				insertIntoClaim.setDate(5, sql);
			}
			insertIntoClaim.setLong(6, MitchellClaim.AssignedAdjusterID);
			insertIntoClaim.execute();

			String causeOfLossInsert = "INSERT INTO CauseOfLoss "
					+ "VALUES (?,?,?,?)";
			PreparedStatement insertIntoCOL = conn
					.prepareStatement(causeOfLossInsert);
			insertIntoCOL.setString(1, MitchellClaim.LossInfo.CauseOfLoss);
			if (MitchellClaim.LossInfo.ReportedDate != null
					&& MitchellClaim.LossInfo.ReportedDate != "") {
				SimpleDateFormat format = new SimpleDateFormat(
						"yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
				Date parsed = format.parse(MitchellClaim.LossInfo.ReportedDate);
				java.sql.Date sql = new java.sql.Date(parsed.getTime());
				insertIntoCOL.setDate(2, sql);
			}
			insertIntoCOL.setString(3, MitchellClaim.LossInfo.LossDescription);
			insertIntoCOL.setString(4, MitchellClaim.ClaimNumber);
			insertIntoCOL.executeUpdate();

			String vehicleInfoInsert = "INSERT INTO VehicleInfo "
					+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement insertIntoVehicleInfo = conn
					.prepareStatement(vehicleInfoInsert);
			insertIntoVehicleInfo.setInt(1,
					MitchellClaim.Vehicles.VehicleDetails.ModelYear);
			insertIntoVehicleInfo.setString(2,
					MitchellClaim.Vehicles.VehicleDetails.MakeDescription);
			insertIntoVehicleInfo.setString(3,
					MitchellClaim.Vehicles.VehicleDetails.ModelDescription);
			insertIntoVehicleInfo.setString(4,
					MitchellClaim.Vehicles.VehicleDetails.EngineDescription);
			insertIntoVehicleInfo.setString(5,
					MitchellClaim.Vehicles.VehicleDetails.ExteriorColor);
			insertIntoVehicleInfo.setString(6,
					MitchellClaim.Vehicles.VehicleDetails.Vin);
			insertIntoVehicleInfo.setString(7,
					MitchellClaim.Vehicles.VehicleDetails.LicPlate);
			insertIntoVehicleInfo.setString(8,
					MitchellClaim.Vehicles.VehicleDetails.LicPlateState);
			if (MitchellClaim.Vehicles.VehicleDetails != null
					&& MitchellClaim.Vehicles.VehicleDetails.LicPlateExpDate != "") {
				SimpleDateFormat format = new SimpleDateFormat(
						"yyyy-MM-dd");
				Date parsed = format
						.parse(MitchellClaim.Vehicles.VehicleDetails.LicPlateExpDate);
				java.sql.Date sql = new java.sql.Date(parsed.getTime());
				insertIntoVehicleInfo.setDate(9, sql);
			}

			insertIntoVehicleInfo.setString(10,
					MitchellClaim.Vehicles.VehicleDetails.DamageDescription);
			insertIntoVehicleInfo.setInt(11,
					MitchellClaim.Vehicles.VehicleDetails.Mileage);
			insertIntoVehicleInfo.setString(12, MitchellClaim.ClaimNumber);

			insertIntoVehicleInfo.executeUpdate();
			conn.commit();
		} catch (Exception e) {
			System.out.println(e.getStackTrace() + e.getLocalizedMessage()
					+ e.getMessage() + e.getCause());
			return "Error while inserting record:"+ e.getCause();
		}

		return ("Record inserted!");
	}

	
	
	public MitchellClaim readClaim(String claimId) {
		setupConnection();
		MitchellClaim claim = new MitchellClaim();
		try {
			String claimRead = "Select * from Claim where ClaimNumber = ?";
			PreparedStatement readFromClaim = conn.prepareStatement(claimRead);
			readFromClaim.setString(1, claimId);
			ResultSet rs = readFromClaim.executeQuery();
		     while (rs.next()) {	     
		    	 claim.ClaimNumber = rs.getString(1);
		    	 claim.ClaimantFirstName = rs.getString(2);
		    	 claim.ClaimantLastName = rs.getString(3);
		    	 claim.Status = rs.getString(4);
		    	 claim.LossDate = (rs.getDate(5)).toString();
		    	 claim.AssignedAdjusterID = (long)rs.getInt(6);
		     }
		     
		     String causeOfLossRead = "Select * from CauseOfLoss where ClaimID = ?";
		     PreparedStatement readFromCauseOfLoss = conn.prepareStatement(causeOfLossRead);
		     readFromCauseOfLoss.setString(1, claimId);
		     rs = readFromCauseOfLoss.executeQuery();
		     while (rs.next()) {
		     LossInfoType COL = new LossInfoType();
		     COL.CauseOfLoss = rs.getString(1);
		     COL.ReportedDate = rs.getDate(2).toString();
		     COL.LossDescription = rs.getString(3);
		     claim.LossInfo=COL;
		     }
		     
		     String vehicleInfoRead = "Select * from VehicleInfo where ClaimId = ?";
		     PreparedStatement readFromVehicleInfo = conn.prepareStatement(vehicleInfoRead);
		     readFromVehicleInfo.setString(1, claimId);
		     rs = readFromVehicleInfo.executeQuery();
		     while (rs.next()) {
		    	 VehicleInfoType vehicleInfo = new VehicleInfoType();
		    	 vehicleInfo.ModelYear = rs.getInt(1);
		    	 vehicleInfo.MakeDescription = rs.getString(2);
		    	 vehicleInfo.ModelDescription = rs.getString(3);
		    	 vehicleInfo.EngineDescription = rs.getString(4);
		    	 vehicleInfo.ExteriorColor = rs.getString(5);
		    	 vehicleInfo.Vin = rs.getString(6);
		    	 vehicleInfo.LicPlate = rs.getString(7);
		    	 vehicleInfo.LicPlateState = rs.getString(8);
		    	 vehicleInfo.LicPlateExpDate = rs.getDate(9).toString();
		    	 vehicleInfo.DamageDescription = rs.getString(10);
		    	 vehicleInfo.Mileage = rs.getInt(11);
		    	 VehicleListType type = new VehicleListType();
		    	 type.VehicleDetails= vehicleInfo;
		    	 claim.Vehicles = type;
		     }
		}
		catch(Exception e){
			System.out.println(e.getStackTrace() + e.getLocalizedMessage()
					+ e.getMessage() + e.getCause());
			return null;
		}
		return claim;
	}
	
	public String[] getListOfClaims(String startDate, String endDate ) {
		setupConnection();
		ArrayList<String> list = new ArrayList<String>();
		try{
			
			String rangeQuery = "Select * from Claim where LossDate BETWEEN ? and ?";
		    PreparedStatement claimBetweenRange = conn.prepareStatement(rangeQuery);
		    claimBetweenRange.setString(1, startDate);
		    claimBetweenRange.setString(2, endDate);
		    ResultSet rs = claimBetweenRange.executeQuery();
		    while (rs.next()) {
		    	list.add(rs.getString(1));
		    }
		}
	    catch(Exception e){
			System.out.println(e.getStackTrace() + e.getLocalizedMessage()
					+ e.getMessage() + e.getCause());
			return null;
		}
		return (String[])list.toArray();
	}
}
