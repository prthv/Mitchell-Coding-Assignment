package us.ac.open.t350;


public class MitchellClaim {
public String ClaimNumber;
public String ClaimantFirstName;
public String ClaimantLastName;
public String Status;

public String LossDate;
public LossInfoType LossInfo; 
public Long AssignedAdjusterID; 
public VehicleListType Vehicles;


}

